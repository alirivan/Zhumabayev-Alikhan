package com.example.EndProj;

import com.example.EndProj.data.PostgresDB;
import com.example.EndProj.data.interfaces.IDB;
import com.example.EndProj.repositories.EmployeeRepository;
import com.example.EndProj.repositories.HospitalRepository;
import com.example.EndProj.repositories.PatientRepository;
import com.example.EndProj.repositories.UserRepository;
import com.example.EndProj.repositories.interfaces.IEmployeeRepository;
import com.example.EndProj.repositories.interfaces.IHospitalRepository;
import com.example.EndProj.repositories.interfaces.IPatientRepository;
import com.example.EndProj.repositories.interfaces.IUserRepository;
import com.example.EndProj.services.*;
import com.example.EndProj.services.interfaces.*;
import org.glassfish.jersey.internal.inject.AbstractBinder;

public class MyApplicationBinder extends AbstractBinder {
    @Override
    protected void configure() {
        bind(PostgresDB.class).to(IDB.class);
        bind(UserRepository.class).to(IUserRepository.class);
        bind(PatientRepository.class).to(IPatientRepository.class);
        bind(PatientService.class).to(IPatientService.class);
        bind(UserService.class).to(IUserService.class);
        bind(AuthService.class).to(IAuthService.class);
        bind(EmployeeRepository.class).to(IEmployeeRepository.class);
        bind(EmployeeService.class).to(IEmployeeService.class);
        bind(HospitalRepository.class).to(IHospitalRepository.class);
        bind(HospitalService.class).to(IHospitalService.class);
    }
}
