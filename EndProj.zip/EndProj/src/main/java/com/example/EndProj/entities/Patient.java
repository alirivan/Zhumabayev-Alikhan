package com.example.EndProj.entities;

import java.util.Date;

public class Patient {
    private int patient_id;
    private String pat_name;
    private String pat_surn;
    private Date birth_date;
    private String gender;
    private String iin;
    private String address;
    private int hospital_id;
    private Hospital hospital;

    public Patient() {

    }

    public Patient(int patient_id, String pat_name, String pat_surn, Date birth_date, String gender, String iin, String address, int hospital_id) {
        this.patient_id = patient_id;
        this.pat_name = pat_name;
        this.pat_surn = pat_surn;
        this.birth_date = birth_date;
        this.gender = gender;
        this.iin = iin;
        this.address = address;
        this.hospital_id = hospital_id;
    }
    public Patient(int patient_id, String pat_name, String pat_surn, Date birth_date, String gender, String iin, String address, int hospital_id, Hospital hospital) {
        this.patient_id = patient_id;
        this.pat_name = pat_name;
        this.pat_surn = pat_surn;
        this.birth_date = birth_date;
        this.gender = gender;
        this.iin = iin;
        this.address = address;
        this.hospital_id = hospital_id;
        this.hospital = hospital;
    }

    public int getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(int patient_id) {
        this.patient_id = patient_id;
    }

    public String getPat_name() {
        return pat_name;
    }

    public void setPat_name(String pat_name) {
        this.pat_name = pat_name;
    }

    public String getPat_surn() {
        return pat_surn;
    }

    public void setPat_surn(String pat_surn) {
        this.pat_surn = pat_surn;
    }

    public Date getBirth_date() {
        return birth_date;
    }

    public void setBirth_date(Date birth_date) {
        this.birth_date = birth_date;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getIin() {
        return iin;
    }

    public void setIin(String iin) {
        this.iin = iin;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getHospital_id() {
        return hospital_id;
    }

    public void setHospital_id(int hospital_id) {
        this.hospital_id = hospital_id;
    }

    public Hospital getHospital() {
        return hospital;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }

    @Override
    public String toString() {
        return "Patient{" +
                "patient_id=" + patient_id +
                ", pat_name='" + pat_name + '\'' +
                ", pat_surn='" + pat_surn + '\'' +
                ", birth_date=" + birth_date +
                ", gender='" + gender + '\'' +
                ", iin='" + iin + '\'' +
                ", address='" + address + '\'' +
                ", hospital_id=" + hospital_id +
                ", hospital=" + hospital +
                '}';
    }
}
