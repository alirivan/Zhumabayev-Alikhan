package com.example.EndProj.repositories;

import com.example.EndProj.data.interfaces.IDB;
import com.example.EndProj.entities.Employee;
import com.example.EndProj.entities.Patient;
import com.example.EndProj.repositories.interfaces.IEmployeeRepository;

import javax.inject.Inject;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class EmployeeRepository implements IEmployeeRepository {
    @Inject
    private IDB db;

    @Override
    public boolean create(Employee employee) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "INSERT INTO employee(employee_id, emp_name, emp_surname, start_date, end_date, phone_number, hospital_id) VALUES (?,?,?,?,?,?,?)";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, employee.getEmployee_id());
            st.setString(2, employee.getEmp_name());
            st.setString(3, employee.getEmp_surname());
            st.setDate(4, (Date) employee.getStart_date());
            st.setDate(5, (Date) employee.getEnd_date());
            st.setLong(6, employee.getPhone_number());
            st.setInt(7, employee.getHospital_id());

            st.execute();
            return true;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public Employee get(int id) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT employee_id, emp_name, emp_surname, start_date, end_date, phone_number, hospital_id FROM employee WHERE employee_id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                Employee employee = new Employee(
                        rs.getInt("employee_id"),
                        rs.getString("emp_name"),
                        rs.getString("emp_surname"),
                        rs.getDate("start_date"),
                        rs.getDate("end_date"),
                        rs.getLong("phone_number"),
                        rs.getInt("hospital_id")
                );
                return employee;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;

    }

    @Override
    public List<Employee> getAll() {
        Connection connection = null;

        try {
            connection = db.getConnection();
            String sql = "SELECT employee_id, emp_name, emp_surname, start_date, end_date, phone_number, hospital_id FROM employee";
            Statement st = connection.createStatement();

            ResultSet rs = st.executeQuery(sql);
            List<Employee> employees = new LinkedList<>();
            while (rs.next()) {
                Employee employee = new Employee(rs.getInt("employee_id"),
                        rs.getString("emp_name"),
                        rs.getString("emp_surname"),
                        rs.getDate("start_date"),
                        rs.getDate("end_date"),
                        rs.getLong("phone_number"),
                        rs.getInt("hospital_id"));

                employees.add(employee);
            }

            return employees;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public boolean delete(int id) {
        Connection connection = null;

        try {
            connection = db.getConnection();
            String sql = "DELETE FROM employee WHERE id=?";
            PreparedStatement st = connection.prepareStatement(sql);

            st.setInt(1, id);
            st.execute();

            return true;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return false;
    }
}
