package com.example.EndProj.repositories;

import com.example.EndProj.data.interfaces.IDB;
import com.example.EndProj.entities.Patient;
import com.example.EndProj.repositories.interfaces.IPatientRepository;

import javax.inject.Inject;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class PatientRepository implements IPatientRepository {
    @Inject
    private IDB db;

    @Override
    public boolean create(Patient patient) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "INSERT INTO patient(patient_id, pat_name, pat_surn, birth_date, gender, iin, address, hospital_id) VALUES (?,?,?,?,?,?,?,?)";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, patient.getPatient_id());
            st.setString(2, patient.getPat_name());
            st.setString(3, patient.getPat_surn());
            st.setDate(4, (Date) patient.getBirth_date());
            st.setString(5, patient.getGender());
            st.setString(6, patient.getIin());
            st.setString(7, patient.getAddress());
            st.setInt(8, patient.getHospital_id());

            st.execute();
            return true;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public Patient get(int id) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT patient_id, pat_name, pat_surn, birth_date, gender, iin, address, hospital_id FROM patient WHERE patient_id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                Patient patient = new Patient(
                        rs.getInt("patient_id"),
                        rs.getString("pat_name"),
                        rs.getString("pat_surn"),
                        rs.getDate("birth_date"),
                        rs.getString("gender"),
                        rs.getString("iin"),
                        rs.getString("address"),
                        rs.getInt("hospital_id")
                );
                return patient;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;

    }

    @Override
    public List<Patient> getAll() {
        Connection connection = null;

        try {
            connection = db.getConnection();
            String sql = "SELECT patient_id, pat_name, pat_surn, birth_date, gender, iin, address, hospital_id FROM patient";
            Statement st = connection.createStatement();

            ResultSet rs = st.executeQuery(sql);
            List<Patient> patients = new LinkedList<>();
            while (rs.next()) {
                Patient patient = new Patient(rs.getInt("patient_id"),
                        rs.getString("pat_name"),
                        rs.getString("pat_surn"),
                        rs.getDate("birth_date"),
                        rs.getString("gender"),
                        rs.getString("iin"),
                        rs.getString("address"),
                        rs.getInt("hospital_id"));

                patients.add(patient);
            }

            return patients;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public boolean delete(int id) {
        Connection connection = null;

        try {
            connection = db.getConnection();
            String sql = "DELETE FROM patient WHERE id=?";
            PreparedStatement st = connection.prepareStatement(sql);

            st.setInt(1, id);
            st.execute();

            return true;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return false;
    }
}
