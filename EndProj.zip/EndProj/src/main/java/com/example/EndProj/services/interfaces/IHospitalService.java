package com.example.EndProj.services.interfaces;

import com.example.EndProj.entities.Hospital;

import java.util.List;

public interface IHospitalService {
    Hospital getHospitalById(int id);
    List<Hospital> getAllHospitals();
    boolean createHospital(Hospital hospital);
    boolean deleteHospital(int id);
}
