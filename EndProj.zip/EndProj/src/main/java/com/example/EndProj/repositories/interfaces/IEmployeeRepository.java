package com.example.EndProj.repositories.interfaces;

import com.example.EndProj.entities.Employee;
import com.example.EndProj.repositories.interfaces.base.IRepository;

public interface IEmployeeRepository extends IRepository<Employee> {
}
