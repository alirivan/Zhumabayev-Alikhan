package com.example.EndProj.entities;

public class Hospital {
    private int hospital_id;
    private String hospital_name;
    private String address;
    private String director_name;
    private String director_surname;
    private long phone_number;
    private String e_mail;

    public Hospital(int hospital_id, String hospital_name, String address, String director_name, String director_surname, long phone_number, String e_mail) {
        this.hospital_id = hospital_id;
        this.hospital_name = hospital_name;
        this.address = address;
        this.director_name = director_name;
        this.director_surname = director_surname;
        this.phone_number = phone_number;
        this.e_mail = e_mail;
    }

    public int getHospital_id() {
        return hospital_id;
    }

    public void setHospital_id(int hospital_id) {
        this.hospital_id = hospital_id;
    }

    public String getHospital_name() {
        return hospital_name;
    }

    public void setHospital_name(String hospital_name) {
        this.hospital_name = hospital_name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDirector_name() {
        return director_name;
    }

    public void setDirector_name(String director_name) {
        this.director_name = director_name;
    }

    public String getDirector_surname() {
        return director_surname;
    }

    public void setDirector_surname(String director_surname) {
        this.director_surname = director_surname;
    }

    public long getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(long phone_number) {
        this.phone_number = phone_number;
    }

    public String getE_mail() {
        return e_mail;
    }

    public void setE_mail(String e_mail) {
        this.e_mail = e_mail;
    }

    @Override
    public String toString() {
        return "Hospital{" +
                "hospital_id=" + hospital_id +
                ", hospital_name='" + hospital_name + '\'' +
                ", address='" + address + '\'' +
                ", director_name='" + director_name + '\'' +
                ", director_surname='" + director_surname + '\'' +
                ", phone_number=" + phone_number +
                ", e_mail='" + e_mail + '\'' +
                '}';
    }
}
