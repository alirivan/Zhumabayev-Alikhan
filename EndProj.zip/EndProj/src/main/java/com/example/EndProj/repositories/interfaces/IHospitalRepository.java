package com.example.EndProj.repositories.interfaces;

import com.example.EndProj.entities.Hospital;
import com.example.EndProj.repositories.interfaces.base.IRepository;

public interface IHospitalRepository extends IRepository<Hospital> {
}
