package com.example.EndProj.services.interfaces;

import com.example.EndProj.entities.Employee;

import java.util.List;

public interface IEmployeeService {
    Employee getEmployeeById(int id);
    List<Employee> getAllEmployees();
    boolean createEmployee(Employee employee);
    boolean deleteEmployee(int id);
}
