package com.example.EndProj.services;

import com.example.EndProj.entities.Patient;
import com.example.EndProj.repositories.interfaces.IPatientRepository;
import com.example.EndProj.services.interfaces.IPatientService;

import javax.inject.Inject;
import java.util.List;

public class PatientService implements IPatientService {
    @Inject
    private IPatientRepository patientRepository;

    @Override
    public Patient getPatientById(int id) {
        return patientRepository.get(id);
    }

    @Override
    public List<Patient> getAllPatients() {
        return patientRepository.getAll();
    }

    @Override
    public boolean createPatient(Patient patient) {
        return patientRepository.create(patient);
    }

    @Override
    public boolean deletePatient(int id) {
        return patientRepository.delete(id);
    }
}
