package com.example.EndProj.services;

import com.example.EndProj.entities.Hospital;
import com.example.EndProj.repositories.interfaces.IHospitalRepository;
import com.example.EndProj.services.interfaces.IHospitalService;

import javax.inject.Inject;
import java.util.List;

public class HospitalService implements IHospitalService {
    @Inject
    private IHospitalRepository hospitalRepository;

    @Override
    public Hospital getHospitalById(int id) {
        return hospitalRepository.get(id);
    }

    @Override
    public List<Hospital> getAllHospitals() {
        return hospitalRepository.getAll();
    }

    @Override
    public boolean createHospital(Hospital hospital) {
        return hospitalRepository.create(hospital);
    }

    @Override
    public boolean deleteHospital(int id) {
        return hospitalRepository.delete(id);
    }
}
