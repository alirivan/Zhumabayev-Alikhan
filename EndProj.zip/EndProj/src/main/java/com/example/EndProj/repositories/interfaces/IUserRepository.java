package com.example.EndProj.repositories.interfaces;

import com.example.EndProj.entities.User;
import com.example.EndProj.repositories.interfaces.base.IRepository;

public interface IUserRepository extends IRepository<User> {
    User getUserByLogin(String username, String password);

    User getUserByUsername(String issuer);
}
