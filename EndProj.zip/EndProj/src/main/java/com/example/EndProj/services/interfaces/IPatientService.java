package com.example.EndProj.services.interfaces;

import com.example.EndProj.entities.Patient;

import java.util.List;

public interface IPatientService {
    Patient getPatientById(int id);
    List<Patient> getAllPatients();
    boolean createPatient(Patient patient);
    boolean deletePatient(int id);
}
