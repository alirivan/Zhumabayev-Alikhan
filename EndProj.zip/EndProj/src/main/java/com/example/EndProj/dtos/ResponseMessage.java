package com.example.EndProj.dtos;

public class ResponseMessage {
    private String message;

    public ResponseMessage(String message) {
        setMessage(message);
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
