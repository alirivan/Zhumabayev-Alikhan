package com.example.EndProj.services;

import com.example.EndProj.entities.Employee;
import com.example.EndProj.repositories.interfaces.IEmployeeRepository;
import com.example.EndProj.services.interfaces.IEmployeeService;

import javax.inject.Inject;
import java.util.List;

public class EmployeeService implements IEmployeeService {
    @Inject
    private IEmployeeRepository employeeRepository;

    @Override
    public Employee getEmployeeById(int id) {
        return employeeRepository.get(id);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.getAll();
    }

    @Override
    public boolean createEmployee(Employee employee) {
        return employeeRepository.create(employee);
    }

    @Override
    public boolean deleteEmployee(int id) {
        return employeeRepository.delete(id);
    }
}
