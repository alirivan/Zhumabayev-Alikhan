package com.example.EndProj.services.interfaces;

import com.example.EndProj.dtos.AccessToken;
import com.example.EndProj.dtos.LoginDto;
import com.example.EndProj.entities.User;

public interface IAuthService {
    AccessToken authenticateUser(LoginDto data) throws Exception;

    User getUserByUsername(String issuer);
}
