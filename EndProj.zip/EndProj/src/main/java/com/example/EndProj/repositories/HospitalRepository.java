package com.example.EndProj.repositories;

import com.example.EndProj.data.interfaces.IDB;
import com.example.EndProj.entities.Hospital;
import com.example.EndProj.repositories.interfaces.IHospitalRepository;

import javax.inject.Inject;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class HospitalRepository implements IHospitalRepository {
    @Inject
    private IDB db;

    @Override
    public boolean create(Hospital hospital) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "INSERT INTO hospital(hospital_id, hospital_name, address, director_name, director_surname, phone_number, e_mail) VALUES (?,?,?,?,?,?,?)";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, hospital.getHospital_id());
            st.setString(2, hospital.getHospital_name());
            st.setString(3, hospital.getAddress());
            st.setString(4, hospital.getDirector_name());
            st.setString(5, hospital.getDirector_surname());
            st.setLong(6, hospital.getPhone_number());
            st.setString(7, hospital.getE_mail());

            st.execute();
            return true;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public Hospital get(int id) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT hospital_id, hospital_name, address, director_name, director_surname, phone_number, e_mail FROM hospital WHERE hospital_id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                Hospital employee = new Hospital(
                        rs.getInt("hospital_id"),
                        rs.getString("hospital_name"),
                        rs.getString("address"),
                        rs.getString("director_name"),
                        rs.getString("director_surname"),
                        rs.getLong("phone_number"),
                        rs.getString("e_mail")
                );
                return employee;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;

    }

    @Override
    public List<Hospital> getAll() {
        Connection connection = null;

        try {
            connection = db.getConnection();
            String sql = "SELECT hospital_id, hospital_name, address, director_name, director_surname, phone_number, e_mail FROM hospital";
            Statement st = connection.createStatement();

            ResultSet rs = st.executeQuery(sql);
            List<Hospital> hospitals = new LinkedList<>();
            while (rs.next()) {
                Hospital hospital = new Hospital(rs.getInt("hospital_id"),
                        rs.getString("hospital_name"),
                        rs.getString("address"),
                        rs.getString("director_name"),
                        rs.getString("director_surname"),
                        rs.getLong("phone_number"),
                        rs.getString("e_mail"));

                hospitals.add(hospital);
            }

            return hospitals;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public boolean delete(int id) {
        Connection connection = null;

        try {
            connection = db.getConnection();
            String sql = "DELETE FROM hospital WHERE id=?";
            PreparedStatement st = connection.prepareStatement(sql);

            st.setInt(1, id);
            st.execute();

            return true;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return false;
    }
}
