package com.example.EndProj.data;

import com.example.EndProj.data.interfaces.IDB;

import java.sql.Connection;
import javax.ws.rs.ServerErrorException;
import java.sql.DriverManager;

public class PostgresDB implements IDB {
    @Override
    public Connection getConnection() {
        String connectionUrl = "jdbc:postgresql://localhost:5432/endtermjava";
        try {
            // Establish the connection
            Connection con = DriverManager.getConnection(connectionUrl, "postgres", "saylord");

            return con;
        } catch (Exception e) {
            System.out.println(e);
            throw new ServerErrorException("Cannot connect to DB", 500);
        }
    }
}
