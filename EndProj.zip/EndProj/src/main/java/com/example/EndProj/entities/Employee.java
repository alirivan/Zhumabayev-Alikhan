package com.example.EndProj.entities;

import java.util.Date;

public class Employee {
    private int employee_id;
    private String emp_name;
    private String emp_surname;
    private Date start_date;
    private Date end_date;
    private long phone_number;
    private int hospital_id;
    private Hospital hospital;

    public Employee() {

    }

    public Employee(int employee_id, String emp_name, String emp_surname, Date start_date, Date end_date, long phone_number, int hospital_id) {
        setEmployee_id(employee_id);
        setEmp_name(emp_name);
        setEmp_surname(emp_surname);
        setStart_date(start_date);
        setEnd_date(end_date);
        setPhone_number(phone_number);
        setHospital_id(hospital_id);
    }

    public Employee(String emp_name, String emp_surname, Date start_date, Date end_date, long phone_number, int hospital_id) {
        setEmp_name(emp_name);
        setEmp_surname(emp_surname);
        setStart_date(start_date);
        setEnd_date(end_date);
        setPhone_number(phone_number);
        setHospital_id(hospital_id);
    }

    public Employee(int employee_id, String emp_name, String emp_surname, Date start_date, Date end_date, long phone_number, int hospital_id, Hospital hospital) {
        this(emp_name, emp_surname, start_date, end_date, phone_number,hospital_id);
        setEmployee_id(employee_id);
        setHospital(hospital);
    }

    public int getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(int employee_id) {
        this.employee_id = employee_id;
    }

    public String getEmp_name() {
        return emp_name;
    }

    public void setEmp_name(String emp_name) {
        this.emp_name = emp_name;
    }

    public String getEmp_surname() {
        return emp_surname;
    }

    public void setEmp_surname(String emp_surname) {
        this.emp_surname = emp_surname;
    }

    public Date getStart_date() {
        return start_date;
    }

    public void setStart_date(Date start_date) {
        this.start_date = start_date;
    }

    public Date getEnd_date() {
        return end_date;
    }

    public void setEnd_date(Date end_date) {
        this.end_date = end_date;
    }

    public long getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(long phone_number) {
        this.phone_number = phone_number;
    }

    public int getHospital_id() {
        return hospital_id;
    }

    public void setHospital_id(int hospital_id) {
        this.hospital_id = hospital_id;
    }

    public Hospital getHospital() {
        return hospital;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employee_id=" + employee_id +
                ", emp_name='" + emp_name + '\'' +
                ", emp_surname='" + emp_surname + '\'' +
                ", start_date=" + start_date +
                ", end_date=" + end_date +
                ", phone_number=" + phone_number +
                ", hospital_id=" + hospital_id +
                ", hospital=" + hospital +
                '}';
    }
}
