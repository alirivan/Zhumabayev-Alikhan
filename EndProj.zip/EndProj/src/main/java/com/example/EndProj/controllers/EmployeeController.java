package com.example.EndProj.controllers;

import com.example.EndProj.entities.Employee;
import com.example.EndProj.filters.customAnnotations.JWTTokenNeeded;
import com.example.EndProj.services.interfaces.IEmployeeService;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("employee")
public class EmployeeController {
    @Inject
    private IEmployeeService employeeService;

    @JWTTokenNeeded
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllEmployees() {
        List<Employee> employees;
        try {
            employees = employeeService.getAllEmployees();
        } catch (ServerErrorException e) {
            return Response
                    .status(500).entity(e.getMessage()).build();
        }

        return Response
                .status(Response.Status.OK)
                .entity(employees)
                .build();
    }

    @JWTTokenNeeded
    @GET
    @Path("/{id}")
    public Response getEmployeeById(@PathParam("id") int id) {
        Employee employee;
        try {
            employee = employeeService.getEmployeeById(id);
        } catch (ServerErrorException ex) {
            return Response
                    .status(500).entity(ex.getMessage()).build();
        }

        if (employee == null) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Employee does not exist!")
                    .build();
        }

        return Response
                .status(Response.Status.OK)
                .entity(employee)
                .build();
    }

    @JWTTokenNeeded
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createEmployee(Employee employee) {
        boolean added;
        try {
            added = employeeService.createEmployee(employee);
        } catch (ServerErrorException e) {
            return Response.serverError().entity(e.getMessage()).build();
        }

        if (!added) {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity("Employee cannot be added!")
                    .build();
        }

        return Response
                .status(Response.Status.CREATED)
                .entity("Employee added successfully!")
                .build();
    }

    @JWTTokenNeeded
    @DELETE
    @Path("/delete/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteEmployee(@PathParam("id") int id) {
        boolean deleted;
        try {
            deleted = employeeService.deleteEmployee(id);
        } catch (ServerErrorException e) {
            return Response.serverError().entity(e.getMessage()).build();
        }

        if (!deleted) {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity("Employee cannot be deleted!")
                    .build();
        }

        return Response
                .status(Response.Status.CREATED)
                .entity("Employee deleted successfully!")
                .build();
    }
}
