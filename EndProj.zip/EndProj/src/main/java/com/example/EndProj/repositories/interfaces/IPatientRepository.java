package com.example.EndProj.repositories.interfaces;

import com.example.EndProj.entities.Patient;
import com.example.EndProj.repositories.interfaces.base.IRepository;

public interface IPatientRepository extends IRepository<Patient> {
}
