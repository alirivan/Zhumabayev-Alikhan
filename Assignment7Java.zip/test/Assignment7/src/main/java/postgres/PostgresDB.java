package postgres;

public class PostgresDB {
}
